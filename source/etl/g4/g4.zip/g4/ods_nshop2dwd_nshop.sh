#!/bin/bash
hive -f ./ods_nshop2dwd_nshop.txt