#!/bin/bash
hive -f ./dws_nshop2dm.txt