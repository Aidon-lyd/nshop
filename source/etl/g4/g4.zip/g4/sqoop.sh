#!/binbash
sqoop export --connect jdbc:mysql://10.0.88.247:3306/ads_nshop \
--driver com.mysql.jdbc.Driver \
--table ads_nshop_result_g4 \
-m 1 \
--username root --password 123456 \
--input-fields-terminated-by '\001' \
--input-fields-terminated-by '\001' \
--input-null-string "\\\N" \
--input-null-non-string "\\\N" \
--export-dir hdfs://qf/hive/db/ads_nshop.db/ads_nshop_customer_stat_g4/*