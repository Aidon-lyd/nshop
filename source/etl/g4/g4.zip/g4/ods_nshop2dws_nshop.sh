#!/bin/bash
hive -f ./ods_nshop2dws_nshop.txt