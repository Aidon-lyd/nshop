#!/bin/bash
hive -f ./dm_nshop2abs.txt