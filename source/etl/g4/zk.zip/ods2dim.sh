#!/bin/bash

####################################################
###��ods���ά�ȱ���Ϣװ�ص�dim��
###
####################################################
#1.dim_nshop.dim_nshop_customer data load
hive -e "
set hive.exec.mode.local.auto=true;
create table if not exists dim_nshop.dim_nshop_customer(
customer_sk varchar(20),
customer_id varchar(20),
customer_login varchar(20),
customer_nickname varchar(20), 
customer_gender TINYINT COMMENT '�Ա�1�� 0Ů',
customer_age int,
customer_age_part varchar(10),
ver varchar(5)
)
location '/data/nshop/ods/dim_pub_customer/'
;
insert overwrite table dim_nshop.dim_nshop_customer
select
customer_sk,
customer_id,
customer_login,
customer_nickname,
customer_gender,
customer_age,
(case when customer_age<=20 then '0-20'
when customer_age>20 and customer_age<=23 then '21-23'
when customer_age>23 and customer_age<=26 then '24-26'
when customer_age>26 and customer_age<=28 then '27-28'
when customer_age>28 and customer_age<=29 then '28-29'
when customer_age>29 and customer_age<=32 then '30-32'
when customer_age>32 and customer_age<=35 then '33-35'
when customer_age>35 and customer_age<=38 then '36-38'
when customer_age>38 and customer_age<=42 then '39-42'
when customer_age>42 and customer_age<=46 then '42-46'
when customer_age>46 and customer_age<=56 then '47-56'
when customer_age>56 and customer_age<=66 then '56-66'
else '66+' end) customer_age_part ,
ver
from (
select
row_number() over() customer_sk,
customer_id,
customer_login,
customer_nickname,
customer_gender,
cast((SUBSTR(FROM_UNIXTIME(UNIX_TIMESTAMP()),1,4)-substr(customer_birthday,1,4)) as int) customer_age,
'1' ver
from
ods_nshop.ods_nshop_02_customer
) t1;
"