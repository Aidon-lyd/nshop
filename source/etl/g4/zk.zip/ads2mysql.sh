#!/bin/bash

yesterday=`date -d "1 days ago" +"%Y-%m-%d"`

sqoop export --connect "jdbc:mysql://10.0.88.247:3306/g4_nshop_result?useUnicode=true&characterEncoding=UTF-8" \
--driver com.mysql.jdbc.Driver \
--table ads_nshop_busi_stat_age_range \
-m 1 \
--username root --password 12345678 \
--input-fields-terminated-by '\001' \
--input-null-string "\\\N" \
--input-null-non-string "\\\N" \
--export-dir hdfs://10.0.88.245:9000/user/hive/warehouse/ads_nshop.db/ads_nshop_busi_stat_age_range/bdp_day=${yesterday}/*

sqoop export --connect "jdbc:mysql://10.0.88.247:3306/g4_nshop_result?useUnicode=true&characterEncoding=UTF-8" \
--driver com.mysql.jdbc.Driver \
--table ads_nshop_busi_stat_category_type \
-m 1 \
--username root --password 12345678 \
--input-fields-terminated-by '\001' \
--input-null-string "\\\N" \
--input-null-non-string "\\\N" \
--export-dir hdfs://10.0.88.245:9000/user/hive/warehouse/ads_nshop.db/ads_nshop_busi_stat_age_range/bdp_day=${yesterday}/*

sqoop export --connect "jdbc:mysql://10.0.88.247:3306/g4_nshop_result?useUnicode=true&characterEncoding=UTF-8" \
--driver com.mysql.jdbc.Driver \
--table ads_nshop_busi_stat_gender \
-m 1 \
--username root --password 12345678 \
--input-fields-terminated-by '\001' \
--input-null-string "\\\N" \
--input-null-non-string "\\\N" \
--export-dir hhdfs://10.0.88.245:9000/user/hive/warehouse/ads_nshop.db/ads_nshop_busi_stat_age_range/bdp_day=${yesterday}/*


sqoop export --connect "jdbc:mysql://10.0.88.247:3306/g4_nshop_result?useUnicode=true&characterEncoding=UTF-8" \
--driver com.mysql.jdbc.Driver \
--table ads_nshop_busi_stat_supplier_type \
-m 1 \
--username root --password 12345678 \
--input-fields-terminated-by '\001' \
--input-null-string "\\\N" \
--input-null-non-string "\\\N" \
--export-dir hdfs://10.0.88.245:9000/user/hive/warehouse/ads_nshop.db/ads_nshop_busi_stat_age_range/bdp_day=${yesterday}/*


sqoop export --connect "jdbc:mysql://10.0.88.247:3306/g4_nshop_result?useUnicode=true&characterEncoding=UTF-8" \
--driver com.mysql.jdbc.Driver \
--table ads_nshop_busi_stat_area \
-m 1 \
--username root --password 12345678 \
--input-fields-terminated-by '\001' \
--input-null-string "\\\N" \
--input-null-non-string "\\\N" \
--export-dir hdfs://10.0.88.245:9000/user/hive/warehouse/ads_nshop.db/ads_nshop_busi_stat_age_range/bdp_day=${yesterday}/*



