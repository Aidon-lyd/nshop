#!/bin/bash

####################################################
###dwd-ads
###
####################################################

yesterday=`date -d "1 days ago" +"%Y-%m-%d"`
#1.�충�����Ͷ������

hive -e "
insert overwrite table ads_nshop.ads_nshop_busi_stat partition (bdp_day='$yesterday')
select 
dimcus.customer_gender customer_gender,
dimcus.customer_age_part age_range,
t1.user_areacode customer_area_code,
dimcat.category_name category_name,
dimsup.supplier_name supplier_name,
null busi_succ_orders ,
null busi_succ_amounts,
null busi_succ_users,
(case when t1.order_status='�ɹ�' then count(*) else null end) busi_succ_products,
null busi_fail_orders,
null busi_fail_amounts
from
(select 
supplier_code,
product_code,
customer_id,
order_id,
pay_count,
user_areacode,
to_date(cast(order_ctime/1000 as timestamp)) order_ctime,
if(order_status=7,'ʧ��','�ɹ�') order_status
from
dwd_nshop.dwd_nshop_orders_details dndnod
where (order_status=5 or order_status=6 or order_status=7) and to_date(cast(order_ctime/1000 as timestamp))='$yesterday'
) t1
join dim_nshop.dim_nshop_customer dimcus
on t1.customer_id=dimcus.customer_id
join dim_nshop.dim_pub_product dimpro
on t1.product_code=dimpro.product_code
join dim_nshop.dim_pub_category dimcat
on dimpro.category_code=dimcat.category_code
join dim_nshop.dim_pub_supplier dimsup
on t1.supplier_code=dimsup.supplier_code
join ods_nshop.ods_nshop_02_orders_pay_records odsord
on t1.order_id=odsord.order_id
group by dimcus.customer_gender,t1.order_status,dimcus.customer_age_part,t1.user_areacode,dimsup.supplier_name,dimcat.category_name,t1.product_code
grouping sets(
(dimcus.customer_gender,t1.order_status,t1.product_code),
(dimcus.customer_age_part,t1.order_status,t1.product_code),
(t1.user_areacode,t1.order_status,t1.product_code),
(dimcat.category_name,t1.order_status,t1.product_code),
(dimsup.supplier_name,t1.order_status,t1.product_code)
)
"

hive -e "
insert overwrite table ads_nshop.ads_nshop_busi_stat partition (bdp_day='$yesterday')
select 
dimcus.customer_gender customer_gender,
dimcus.customer_age_part age_range,
t1.user_areacode customer_area_code,
dimcat.category_name category_name,
dimsup.supplier_name supplier_name,
(case when t1.order_status='�ɹ�' then count(*) else null end) busi_succ_orders ,
(case when t1.order_status='�ɹ�' then sum(odsord.pay_amount) else null end) busi_succ_amounts,
(case when t1.order_status='�ɹ�' then count(*) else null end)  busi_succ_users,
null busi_succ_products,
(case when t1.order_status='ʧ��' then count(*) else null end) busi_fail_orders ,
(case when t1.order_status='ʧ��' then sum(odsord.pay_amount) else null end) busi_fail_amounts
from
(select 
supplier_code,
product_code,
customer_id,
order_id,
pay_count,
user_areacode,
to_date(cast(order_ctime/1000 as timestamp)) order_ctime,
if(order_status=7,'ʧ��','�ɹ�') order_status
from
dwd_nshop.dwd_nshop_orders_details dndnod
where (order_status=5 or order_status=6 or order_status=7) and to_date(cast(order_ctime/1000 as timestamp))='$yesterday'
) t1
join dim_nshop.dim_nshop_customer dimcus
on t1.customer_id=dimcus.customer_id
join dim_nshop.dim_pub_product dimpro
on t1.product_code=dimpro.product_code
join dim_nshop.dim_pub_category dimcat
on dimpro.category_code=dimcat.category_code
join dim_nshop.dim_pub_supplier dimsup
on t1.supplier_code=dimsup.supplier_code
join ods_nshop.ods_nshop_02_orders_pay_records odsord
on t1.order_id=odsord.order_id
group by dimcus.customer_gender,t1.order_status,dimcus.customer_age_part,t1.user_areacode,dimsup.supplier_name,dimcat.category_name,t1.product_code
grouping sets(
(dimcus.customer_gender,t1.order_status),
(dimcus.customer_age_part,t1.order_status),
(t1.user_areacode,t1.order_status),
(dimcat.category_name,t1.order_status),
(dimsup.supplier_name,t1.order_status)
)
"