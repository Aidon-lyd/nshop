#!/bin/bash

hive -e "
set hive.exec.dynamic.partition.mode=nonstrict;
create external table if not exists ads_nshop.ads_nshop_busi_stat_age_range( 
age_range string COMMENT '年龄段',
busi_succ_orders int comment '交易成功订单数', 
busi_succ_amounts int comment '交易成功金额', 
busi_succ_users int comment '交易成功买家数', 
busi_succ_products int comment '交易成功商品数', 
busi_fail_orders int comment '交易失败订单数', 
busi_fail_amounts int comment '交易失败金额' 
) 
partitioned by (bdp_day string) 
;
INSERT OVERWRITE TABLE ads_nshop.ads_nshop_busi_stat_age_range PARTITION (bdp_day)
SELECT
a.age_range,
a.busi_succ_orders,
a.busi_succ_amounts,
a.busi_succ_users,
sum(b.busi_succ_products) busi_succ_products,
a.busi_fail_orders,
a.busi_fail_amounts,
a.bdp_day
FROM
(select * from
ads_nshop.ads_nshop_busi_stat_tmp 
where busi_succ_products is null
)a
join (select * from ads_nshop.ads_nshop_busi_stat_tmp where busi_succ_products is not null)b
on a.age_range=b.age_range
group by 
a.age_range,
a.busi_succ_orders,
a.busi_succ_amounts,
a.busi_succ_users,
a.busi_fail_orders,
a.busi_fail_amounts,
a.bdp_day
;
"

hive -e "
set hive.exec.dynamic.partition.mode=nonstrict;
create external table if not exists ads_nshop.ads_nshop_busi_stat_gender( 
customer_gender TINYINT COMMENT '性别：1男 0女', 
busi_succ_orders int comment '交易成功订单数', 
busi_succ_amounts int comment '交易成功金额', 
busi_succ_users int comment '交易成功买家数', 
busi_succ_products int comment '交易成功商品数', 
busi_fail_orders int comment '交易失败订单数', 
busi_fail_amounts int comment '交易失败金额' 
) 
partitioned by (bdp_day string) 
;

INSERT OVERWRITE TABLE ads_nshop.ads_nshop_busi_stat_gender PARTITION (bdp_day)
SELECT
a.customer_gender,
a.busi_succ_orders,
a.busi_succ_amounts,
a.busi_succ_users,
sum(b.busi_succ_products) busi_succ_products,
a.busi_fail_orders,
a.busi_fail_amounts,
a.bdp_day
FROM
(select * from
ads_nshop.ads_nshop_busi_stat_tmp 
where busi_succ_products is null
)a
join (select * from ads_nshop.ads_nshop_busi_stat_tmp where busi_succ_products is not null)b
on a.customer_gender=b.customer_gender
group by 
a.customer_gender,
a.busi_succ_orders,
a.busi_succ_amounts,
a.busi_succ_users,
a.busi_fail_orders,
a.busi_fail_amounts,
a.bdp_day
;
"


hive -e "
set hive.exec.dynamic.partition.mode=nonstrict;
create external table if not exists ads_nshop.ads_nshop_busi_stat_area( 
customer_area_code string COMMENT '所在地区', 
busi_succ_orders int comment '交易成功订单数', 
busi_succ_amounts int comment '交易成功金额', 
busi_succ_users int comment '交易成功买家数', 
busi_succ_products int comment '交易成功商品数', 
busi_fail_orders int comment '交易失败订单数', 
busi_fail_amounts int comment '交易失败金额' 
) 
partitioned by (bdp_day string) 
;


INSERT OVERWRITE TABLE ads_nshop.ads_nshop_busi_stat_area PARTITION (bdp_day)
SELECT
a.customer_area_code,
a.busi_succ_orders,
a.busi_succ_amounts,
a.busi_succ_users,
sum(b.busi_succ_products) busi_succ_products,
a.busi_fail_orders,
a.busi_fail_amounts,
a.bdp_day
FROM
(select * from
ads_nshop.ads_nshop_busi_stat_tmp 
where busi_succ_products is null
)a
join (select * from ads_nshop.ads_nshop_busi_stat_tmp where busi_succ_products is not null)b
on a.customer_area_code=b.customer_area_code
group by 
a.customer_area_code,
a.busi_succ_orders,
a.busi_succ_amounts,
a.busi_succ_users,
a.busi_fail_orders,
a.busi_fail_amounts,
a.bdp_day
;
"

hive -e "
set hive.exec.dynamic.partition.mode=nonstrict;
create external table if not exists ads_nshop.ads_nshop_busi_stat_category_type( 
category_type string COMMENT '商品类别', 
busi_succ_orders int comment '交易成功订单数', 
busi_succ_amounts int comment '交易成功金额', 
busi_succ_users int comment '交易成功买家数', 
busi_succ_products int comment '交易成功商品数', 
busi_fail_orders int comment '交易失败订单数', 
busi_fail_amounts int comment '交易失败金额' 
) 
partitioned by (bdp_day string) 
;


INSERT OVERWRITE TABLE ads_nshop.ads_nshop_busi_stat_category_type PARTITION (bdp_day)
SELECT
a.category_type,
a.busi_succ_orders,
a.busi_succ_amounts,
a.busi_succ_users,
sum(b.busi_succ_products) busi_succ_products,
a.busi_fail_orders,
a.busi_fail_amounts,
a.bdp_day
FROM
(select * from
ads_nshop.ads_nshop_busi_stat_tmp 
where busi_succ_products is null
)a
join (select * from ads_nshop.ads_nshop_busi_stat_tmp where busi_succ_products is not null)b
on a.category_type=b.category_type
group by 
a.category_type,
a.busi_succ_orders,
a.busi_succ_amounts,
a.busi_succ_users,
a.busi_fail_orders,
a.busi_fail_amounts,
a.bdp_day
;
"

hive -e "
set hive.exec.dynamic.partition.mode=nonstrict;
create external table if not exists ads_nshop.ads_nshop_busi_stat_supplier_type( 
supplier_type string COMMENT '店铺类别', 
busi_succ_orders int comment '交易成功订单数', 
busi_succ_amounts int comment '交易成功金额', 
busi_succ_users int comment '交易成功买家数', 
busi_succ_products int comment '交易成功商品数', 
busi_fail_orders int comment '交易失败订单数', 
busi_fail_amounts int comment '交易失败金额' 
) 
partitioned by (bdp_day string) 
;
INSERT OVERWRITE TABLE ads_nshop.ads_nshop_busi_stat_supplier_type PARTITION (bdp_day)
SELECT
a.supplier_type,
a.busi_succ_orders,
a.busi_succ_amounts,
a.busi_succ_users,
sum(b.busi_succ_products) busi_succ_products,
a.busi_fail_orders,
a.busi_fail_amounts,
a.bdp_day
FROM
(select * from
ads_nshop.ads_nshop_busi_stat_tmp 
where busi_succ_products is null
)a
join (select * from ads_nshop.ads_nshop_busi_stat_tmp where busi_succ_products is not null)b
on a.supplier_type=b.supplier_type
group by 
a.supplier_type,
a.busi_succ_orders,
a.busi_succ_amounts,
a.busi_succ_users,
a.busi_fail_orders,
a.busi_fail_amounts,
a.bdp_day
;
"

